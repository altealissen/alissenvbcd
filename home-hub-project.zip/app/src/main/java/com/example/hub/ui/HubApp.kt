package com.example.hub.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Главная", Icons.Rounded.Home),
    Music("Музыка", Icons.Rounded.MusicNote),
    Devices("Устройства", Icons.Rounded.Devices),
    Assistant("Ассистент", Icons.Rounded.Mic),
    Settings("Настройки", Icons.Rounded.Settings),
}

@Composable
fun HubApp(vm: HubViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }

    // Пока подключение не настроено, показываем только настройки.
    val needSetup = state.url.isBlank() || state.token.isBlank()
    val current = if (needSetup) Tab.Settings else tab

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            NavigationRail(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                Box(Modifier.weight(1f))
                Tab.entries.forEach { t ->
                    NavigationRailItem(
                        selected = current == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                    )
                }
                Box(Modifier.weight(1f))
            }
            Box(Modifier.weight(1f).fillMaxSize().padding(24.dp)) {
                when (current) {
                    Tab.Home -> HomeScreen(state, vm)
                    Tab.Music -> MusicScreen(state, vm)
                    Tab.Devices -> DevicesScreen(state, vm)
                    Tab.Assistant -> AssistantScreen(state, vm)
                    Tab.Settings -> SettingsScreen(state, vm)
                }
            }
        }
    }
}

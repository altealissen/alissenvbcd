package com.example.hub.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hub.data.HaClient
import com.example.hub.data.HaEntity
import com.example.hub.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

data class ChatMsg(val fromUser: Boolean, val text: String)

data class UiState(
    val entities: List<HaEntity> = emptyList(),
    val connected: Boolean = false,
    val error: String? = null,
    val url: String = "",
    val token: String = "",
    val playerId: String = "",
    val chat: List<ChatMsg> = emptyList(),
    val assistBusy: Boolean = false,
) {
    val players: List<HaEntity> get() = entities.filter { it.domain == "media_player" }

    /** Выбранный плеер; если не выбран, берём играющий, иначе первый. */
    val player: HaEntity?
        get() = players.firstOrNull { it.id == playerId }
            ?: players.firstOrNull { it.state == "playing" }
            ?: players.firstOrNull()
}

class HubViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val _state = MutableStateFlow(
        UiState(url = prefs.url, token = prefs.token, playerId = prefs.player)
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var client: HaClient? = null
    private var poll: Job? = null

    init {
        restart()
    }

    private fun restart() {
        poll?.cancel()
        val s = _state.value
        if (s.url.isBlank() || s.token.isBlank()) {
            client = null
            _state.update { it.copy(connected = false, error = null, entities = emptyList()) }
            return
        }
        val c = HaClient(s.url, s.token)
        client = c
        poll = viewModelScope.launch {
            while (isActive) {
                refresh(c)
                delay(3000)
            }
        }
    }

    private suspend fun refresh(c: HaClient) {
        try {
            val list = c.states()
            _state.update { it.copy(entities = list, connected = true, error = null) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _state.update { it.copy(connected = false, error = e.message ?: "Нет связи с Home Assistant") }
        }
    }

    fun saveSettings(url: String, token: String) {
        prefs.url = url.trim()
        prefs.token = token.trim()
        _state.update { it.copy(url = prefs.url, token = prefs.token) }
        restart()
    }

    fun selectPlayer(id: String) {
        prefs.player = id
        _state.update { it.copy(playerId = id) }
    }

    private fun call(domain: String, service: String, data: JSONObject) {
        val c = client ?: return
        viewModelScope.launch {
            try {
                c.callService(domain, service, data)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message) }
            }
            refresh(c)
        }
    }

    fun toggle(e: HaEntity) =
        call("homeassistant", "toggle", JSONObject().put("entity_id", e.id))

    fun mediaCommand(service: String) {
        val p = _state.value.player ?: return
        call("media_player", service, JSONObject().put("entity_id", p.id))
    }

    fun setVolume(level: Float) {
        val p = _state.value.player ?: return
        call(
            "media_player", "volume_set",
            JSONObject().put("entity_id", p.id).put("volume_level", level.toDouble())
        )
    }

    fun ask(text: String) {
        val c = client ?: return
        val q = text.trim()
        if (q.isEmpty()) return
        _state.update { it.copy(chat = it.chat + ChatMsg(true, q), assistBusy = true) }
        viewModelScope.launch {
            val answer = try {
                c.converse(q)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                "Ошибка: ${e.message}"
            }
            _state.update { it.copy(chat = it.chat + ChatMsg(false, answer), assistBusy = false) }
            refresh(c)
        }
    }
}

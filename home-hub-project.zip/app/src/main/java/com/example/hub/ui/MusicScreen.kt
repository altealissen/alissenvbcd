package com.example.hub.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun MusicScreen(state: UiState, vm: HubViewModel) {
    val player = state.player
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Музыка", style = MaterialTheme.typography.headlineMedium)

        if (player == null) {
            Text(
                if (state.connected) "В Home Assistant нет медиаплееров" else (state.error ?: "Нет подключения"),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            return@Column
        }

        // Выбор плеера.
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            state.players.forEach { p ->
                FilterChip(
                    selected = p.id == player.id,
                    onClick = { vm.selectPlayer(p.id) },
                    label = { Text(p.name) },
                )
            }
        }

        Row(
            Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(32.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // «Обложка»: настоящую обложку можно подгрузить из entity_picture.
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = MaterialTheme.shapes.extraLarge,
                modifier = Modifier.size(220.dp),
            ) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Rounded.MusicNote, null,
                        Modifier.size(96.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }

            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    player.attrs.optString("media_title", "Ничего не играет"),
                    style = MaterialTheme.typography.headlineLarge,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    player.attrs.optString("media_artist", player.name),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(16.dp))

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    FilledTonalIconButton(onClick = { vm.mediaCommand("media_previous_track") }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "Назад")
                    }
                    FilledIconButton(onClick = { vm.mediaCommand("media_play_pause") }, modifier = Modifier.size(72.dp)) {
                        Icon(
                            if (player.state == "playing") Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            "Пуск/пауза", Modifier.size(36.dp),
                        )
                    }
                    FilledTonalIconButton(onClick = { vm.mediaCommand("media_next_track") }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipNext, "Вперёд")
                    }
                }

                Spacer(Modifier.height(8.dp))
                val serverVolume = player.attrs.optDouble("volume_level", 0.0).toFloat()
                var volume by remember(player.id, serverVolume) { mutableFloatStateOf(serverVolume) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.VolumeUp, null)
                    Spacer(Modifier.width(12.dp))
                    Slider(
                        value = volume,
                        onValueChange = { volume = it },
                        onValueChangeFinished = { vm.setVolume(volume) },
                        modifier = Modifier.fillMaxWidth(0.8f),
                    )
                }
            }
        }
    }
}

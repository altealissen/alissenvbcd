package com.example.hub.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Одна сущность Home Assistant (лампа, розетка, датчик, медиаплеер и т.д.). */
data class HaEntity(val id: String, val state: String, val attrs: JSONObject) {
    val domain: String get() = id.substringBefore('.')
    val name: String get() = attrs.optString("friendly_name", id)
    val isOn: Boolean get() = state == "on" || state == "playing" || state == "open" || state == "unlocked"
    val unit: String get() = attrs.optString("unit_of_measurement", "")
    val toggleable: Boolean
        get() = domain in setOf("light", "switch", "fan", "input_boolean", "automation")
}

/** Простой REST-клиент Home Assistant: https://developers.home-assistant.io/docs/api/rest/ */
class HaClient(baseUrl: String, private val token: String) {
    private val base = baseUrl.trim().trimEnd('/')
    private val json = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private fun request(path: String) = Request.Builder()
        .url(base + path)
        .header("Authorization", "Bearer $token")

    suspend fun states(): List<HaEntity> = withContext(Dispatchers.IO) {
        http.newCall(request("/api/states").build()).execute().use { r ->
            if (!r.isSuccessful) error(if (r.code == 401) "Неверный токен (401)" else "Ошибка HTTP ${r.code}")
            val arr = JSONArray(r.body!!.string())
            List(arr.length()) {
                val o = arr.getJSONObject(it)
                HaEntity(o.getString("entity_id"), o.getString("state"), o.optJSONObject("attributes") ?: JSONObject())
            }
        }
    }

    suspend fun callService(domain: String, service: String, data: JSONObject) = withContext(Dispatchers.IO) {
        val req = request("/api/services/$domain/$service").post(data.toString().toRequestBody(json)).build()
        http.newCall(req).execute().use { r -> if (!r.isSuccessful) error("Ошибка HTTP ${r.code}") }
    }

    /** Отправляет текст в Assist (встроенный разговорный агент Home Assistant). */
    suspend fun converse(text: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("text", text).put("language", "ru")
        val req = request("/api/conversation/process").post(body.toString().toRequestBody(json)).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Ошибка HTTP ${r.code}")
            JSONObject(r.body!!.string())
                .optJSONObject("response")
                ?.optJSONObject("speech")
                ?.optJSONObject("plain")
                ?.optString("speech")
                ?.takeIf { it.isNotBlank() }
                ?: "Нет ответа"
        }
    }
}

/** Настройки подключения, хранятся локально на телефоне. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("hub", Context.MODE_PRIVATE)
    var url: String
        get() = sp.getString("url", "") ?: ""
        set(v) = sp.edit().putString("url", v).apply()
    var token: String
        get() = sp.getString("token", "") ?: ""
        set(v) = sp.edit().putString("token", v).apply()
    var player: String
        get() = sp.getString("player", "") ?: ""
        set(v) = sp.edit().putString("player", v).apply()
}

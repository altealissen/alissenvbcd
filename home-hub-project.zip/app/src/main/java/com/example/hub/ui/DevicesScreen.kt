package com.example.hub.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Window
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.hub.data.HaEntity

private enum class Group(val label: String, val domains: Set<String>) {
    All("Все", setOf("light", "switch", "fan", "input_boolean", "cover", "lock", "climate", "automation")),
    Light("Свет", setOf("light")),
    Switch("Розетки", setOf("switch", "input_boolean", "fan")),
    Sensor("Датчики", setOf("sensor", "binary_sensor")),
}

private fun HaEntity.icon(): ImageVector = when (domain) {
    "light" -> Icons.Rounded.Lightbulb
    "fan" -> Icons.Rounded.Air
    "lock" -> Icons.Rounded.Lock
    "climate" -> Icons.Rounded.Thermostat
    "cover" -> Icons.Rounded.Window
    "sensor", "binary_sensor" -> Icons.Rounded.Sensors
    else -> Icons.Rounded.PowerSettingsNew
}

private fun HaEntity.stateLabel(): String = when {
    state == "on" -> "Вкл"
    state == "off" -> "Выкл"
    state == "unavailable" -> "Недоступно"
    unit.isNotEmpty() -> "$state $unit"
    else -> state
}

/** Карточка устройства: включённые подсвечиваются цветом primaryContainer. */
@Composable
fun DeviceCard(e: HaEntity, onToggle: () -> Unit) {
    val on = e.isOn
    Card(
        onClick = { if (e.toggleable) onToggle() },
        colors = CardDefaults.cardColors(
            containerColor = if (on) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerHigh,
            contentColor = if (on) MaterialTheme.colorScheme.onPrimaryContainer
            else MaterialTheme.colorScheme.onSurface,
        ),
        modifier = Modifier.fillMaxWidth().height(112.dp),
    ) {
        Column(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Icon(e.icon(), contentDescription = null)
            Column {
                Text(
                    e.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(e.stateLabel(), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun DevicesScreen(state: UiState, vm: HubViewModel) {
    var group by rememberSaveable { mutableStateOf(Group.All) }
    val list = state.entities
        .filter { it.domain in group.domains }
        .sortedWith(compareBy({ it.domain }, { it.name }))

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Устройства", style = MaterialTheme.typography.headlineMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Group.entries.forEach { g ->
                FilterChip(
                    selected = group == g,
                    onClick = { group = g },
                    label = { Text(g.label) },
                )
            }
        }
        if (list.isEmpty()) {
            Text(
                if (state.connected) "Здесь пока ничего нет" else (state.error ?: "Нет подключения"),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(170.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(list, key = { it.id }) { e -> DeviceCard(e, onToggle = { vm.toggle(e) }) }
        }
    }
}

package com.example.hub.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(state: UiState, vm: HubViewModel) {
    var url by remember { mutableStateOf(state.url) }
    var token by remember { mutableStateOf(state.token) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Подключение к Home Assistant на вашем NAS. Токен создаётся в профиле Home Assistant: " +
                "«Безопасность» → «Долгосрочные токены доступа».",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Адрес, например http://192.168.1.10:8123") },
            singleLine = true,
            modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth(),
        )
        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("Долгосрочный токен") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth(),
        )
        Button(onClick = { vm.saveSettings(url, token) }) { Text("Сохранить и подключиться") }

        Text(
            when {
                state.connected -> "Подключено · сущностей: ${state.entities.size}"
                state.error != null -> "Ошибка: ${state.error}"
                else -> "Не подключено"
            },
            style = MaterialTheme.typography.bodyMedium,
            color = if (state.connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
    }
}
